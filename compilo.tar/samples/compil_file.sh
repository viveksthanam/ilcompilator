#permet de donner simplement un fichier � compiler
cat $1 | ../src/compil -d

