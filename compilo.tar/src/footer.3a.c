

fprintf(stderr,"fin ex�cution cible 3@ compil� en C.\n");

return (0);

}

