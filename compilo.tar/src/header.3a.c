#include <stdio.h>

int main (void) {
fprintf(stderr,"d�but ex�cution cible 3@ compil� en C...\n");


