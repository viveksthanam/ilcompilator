// vim: ts=2 tw=80

/** \file symbol.h
 * \brief D�finit la classe CSymbol, contient les symboles
 *        utilis�es dans le compilateur.
 * \author <brossill@enseirb.fr> <lerouxj@enseirb.fr>
 * \version
 * \date 07/12/2006
 *
 */

#ifndef SYMBOL_H
#define SYMBOL_H

#include "stringid.h"
#include "type.h"

#define INVALID_SYMBOL (SymbolID)(-1)

typedef int SymbolID;

class CSymbol
{
private:

  SymbolID id;
  CStringID sid;
  CType type;

public:

  CSymbol( SymbolID id, CStringID sid, CType type )
  {
    this->id = id;
    this->sid = sid;
    this->type = type;
  }

  SymbolID getID() { return this->id; };
  CStringID getSID() { return this->sid; };
  CType getType() { return this->type; };

};

#endif/*SYMBOL_H*/
